def main():
    print("My guitars!")
    print("Name: Fender Stratocaster")
    print("Year: 2014")
    print("Cost: $765.4")
    print("Fender Stratocaster (2014) : $765.40 added.")

main()